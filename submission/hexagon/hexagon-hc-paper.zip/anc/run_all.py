"""Run every numerical check attached to this paper and summarise the results.

Usage (Python 3.8+, standard library only, no network):

    cd anc
    python3 run_all.py            # runs every check script, prints PASS/FAIL per script
    python3 <script>.py           # runs one check; most accept an optional integer seed

Every script uses exact integer / rational arithmetic and prints PASS or FAIL (or a final count of
failures). Reference outputs recorded when the paper was submitted are, where present, in the matching
<script>.log files. The scripts are also in the project repository,
https://github.com/xennygrimmato/eth-hamiltonicity (directory research/scripts).
"""
import os, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__))
CHECKS = [s for s in sorted(os.listdir(HERE))
          if s.endswith(".py") and s != "run_all.py" and not s.endswith("_lib.py")
          and s not in ("ext_engine.py", "ext_problems.py", "review_exact_count.py")]


def main():
    bad = 0
    for s in CHECKS:
        r = subprocess.run([sys.executable, os.path.join(HERE, s)], cwd=HERE,
                           capture_output=True, text=True)
        tail = (r.stdout.strip().splitlines() or [""])[-1]
        ok = r.returncode == 0 and "FAIL" not in tail.upper().replace("FAILURES", "").replace("0 FAIL", "")
        bad += not ok
        print(f"{'ok  ' if ok else 'FAIL'} {s:40s} {tail[:100]}")
    print("ALL CHECKS PASSED" if bad == 0 else f"{bad} script(s) did not pass")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
